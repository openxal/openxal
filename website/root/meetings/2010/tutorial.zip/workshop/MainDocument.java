/*
 * MainDocument.java
 *
 * Created by t6p on 4/27/2010
 */

package gov.sns.apps.workshop;

import java.awt.event.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

import gov.sns.application.*;
import gov.sns.xal.smf.*;
import gov.sns.xal.smf.impl.*;
import gov.sns.xal.smf.application.*;
import gov.sns.tools.bricks.WindowReference;
import gov.sns.tools.swing.*;
import gov.sns.tools.xml.XmlDataAdaptor;
import gov.sns.tools.data.*;


/**
 * MainDocument is a custom XalDocument for this application.
 * @author  t6p
 */
public class MainDocument extends AcceleratorDocument implements DataListener {
	/** the data adaptor label used for reading and writing this document */
	static public final String DATA_LABEL = "WorkshopDocument";

	/** magnet table model */
	private final KeyValueFilteredTableModel<Electromagnet> MAGNET_TABLE_MODEL;
	
	
    /** Create a new empty document */
    public MainDocument() {
        this( null );
    }
    
    
    /** 
     * Create a new document loaded from the URL file 
     * @param url The URL of the file to load into the new document.
     */
    public MainDocument( final URL url ) {
        setSource( url );
		
		MAGNET_TABLE_MODEL = new KeyValueFilteredTableModel<Electromagnet>();
		MAGNET_TABLE_MODEL.setKeyPaths( "id", "magBucket.effLength", "type", "mainSupply.id", "rollAngle", "status" );
		MAGNET_TABLE_MODEL.setMatchingKeyPaths( "id", "type", "mainSupply.id" );
		MAGNET_TABLE_MODEL.setColumnName( "id", "Magnet" );
		MAGNET_TABLE_MODEL.setColumnName( "mainSupply.id", "Main Supply" );
		MAGNET_TABLE_MODEL.setColumnName( "magBucket.effLength", "Magnetic Length" );
		MAGNET_TABLE_MODEL.setColumnClass( "magBucket.effLength", Double.class );
		MAGNET_TABLE_MODEL.setColumnClass( "status", Boolean.class );
		MAGNET_TABLE_MODEL.setColumnClass( "rollAngle", Double.class );
		MAGNET_TABLE_MODEL.setColumnEditKeyPath( "rollAngle", "status" );
		MAGNET_TABLE_MODEL.setColumnEditable( "status", true );
		
		MAGNET_TABLE_MODEL.addKeyValueRecordListener( new KeyValueRecordListener<KeyValueTableModel,Electromagnet>() {
			public void recordModified( final KeyValueTableModel tableModel, final Electromagnet magnet, final String keyPath, final Object value ) {
				setHasChanges( true );
			}
		});
		
        if ( url != null ) {
            System.out.println( "Opening document: " + url.toString() );
            final DataAdaptor documentAdaptor = XmlDataAdaptor.adaptorForUrl( url, false );
            update( documentAdaptor.childAdaptor( dataLabel() ) );
        }		
    }
    
    
    /** Make a main window by instantiating the custom window from the bricks file. */
    public void makeMainWindow() {
		final WindowReference windowReference = getDefaultWindowReference( "MainWindow", this );
        mainWindow = (XalWindow)windowReference.getWindow();
		
		final JTable magnetTable = (JTable)windowReference.getView( "Magnet Table" );
		magnetTable.setModel( MAGNET_TABLE_MODEL );
		
		final JTextField magnetFilterField = (JTextField)windowReference.getView( "Magnet Filter Field" );
		MAGNET_TABLE_MODEL.setInputFilterComponent( magnetFilterField );

		
		final JButton runButton = (JButton)windowReference.getView( "Run Button" );
		runButton.addActionListener( new ActionListener() {
			public void actionPerformed( final ActionEvent event ) {
				performRun();
			}
		});
		
		setHasChanges( false );
	}
	
	
	/**
	 * Register actions specific to this document's instance.
	 * @param commander  The commander with which to register the custom commands.
	 */
	protected void customizeCommands( final Commander commander ) {
		// add your custom actions here
		final Action greetAction = new AbstractAction( "greet-action" ) {
			public void actionPerformed( final ActionEvent event ) {
				JOptionPane.showMessageDialog( mainWindow, "Welcome to XAL Workshop 2010!" );
			}
		};
		commander.registerAction( greetAction );		

		// add your custom actions here
		final Action demoAction = new AbstractAction( "demo-action" ) {
			public void actionPerformed( final ActionEvent event ) {
				JOptionPane.showMessageDialog( mainWindow, "This is a demo." );
			}
		};
		commander.registerAction( demoAction );		

		// add your custom actions here
		final Action piAction = new AbstractAction( "print-pi" ) {
			public void actionPerformed( final ActionEvent event ) {
				JOptionPane.showMessageDialog( mainWindow, "PI: " + Math.PI );
			}
		};
		commander.registerAction( piAction );		
	}
	
    
    /**
     * Save the document to the specified URL.
     * @param url The URL to which the document should be saved.
     */
    public void saveDocumentAs( final URL url ) {
		try {
            final XmlDataAdaptor documentAdaptor = XmlDataAdaptor.newEmptyDocumentAdaptor();
            documentAdaptor.writeNode( this );
            documentAdaptor.writeToUrl( url );
            setHasChanges( false );
        }
        catch( XmlDataAdaptor.WriteException exception ) {
			if ( exception.getCause() instanceof java.io.FileNotFoundException ) {
				System.err.println( exception );
				displayError( "Save Failed!", "Save failed due to a file access exception!", exception );
			}
			else if ( exception.getCause() instanceof java.io.IOException ) {
				System.err.println( exception );
				displayError( "Save Failed!", "Save failed due to a file IO exception!", exception );
			}
			else {
				exception.printStackTrace();
				displayError( "Save Failed!", "Save failed due to an internal write exception!", exception );
			}
        }
        catch(Exception exception) {
			exception.printStackTrace();
            displayError( "Save Failed!", "Save failed due to an internal exception!", exception );
        }

	}
	
	
	/** Implement this method to provide custom handling of accelerator change events. */
	public void acceleratorChanged() {
		selectedSequenceChanged();
		
		// put your custom code here
	}


	/** Implement this method to provide custom handling of accelerator sequence change events. */
	public void selectedSequenceChanged() {
		setHasChanges( true );
		
		if ( selectedSequence != null ) {
			final List<AcceleratorNode> nodes = selectedSequence.getNodesOfType( Electromagnet.s_strType, true );
			final List<Electromagnet> magnets = new ArrayList( nodes );
			MAGNET_TABLE_MODEL.setRecords( magnets );
		}
		else {
			MAGNET_TABLE_MODEL.setRecords( null );
		}
	}
	
	
	/** Perform a run */
	private void performRun() {
		JOptionPane.showMessageDialog( mainWindow, "Running the online model..." );
	}
	
    
    /** provides the name used to identify the class in an external data source. */
    public String dataLabel() {
        return DATA_LABEL;
    }
    
    
    /** Instructs the receiver to update its data based on the given adaptor. */
    public void update( final DataAdaptor adaptor ) {
		if ( adaptor.hasAttribute( "acceleratorPath" ) ) {
			final String acceleratorPath = adaptor.stringValue( "acceleratorPath" );
			final Accelerator accelerator = applySelectedAcceleratorWithDefaultPath( acceleratorPath );
			
			if ( accelerator != null && adaptor.hasAttribute( "sequence" ) ) {
				final String sequenceID = adaptor.stringValue( "sequence" );
				final AcceleratorSeq sequence = getAccelerator().findSequence( sequenceID );
				setSelectedSequence( sequence );
				
				for ( final DataAdaptor magnetAdaptor : adaptor.childAdaptors( "Magnet" ) ) {
					final String magnetID = magnetAdaptor.stringValue( "id" );
					final Electromagnet magnet = (Electromagnet)sequence.getNodeWithId( magnetID );
					magnet.setStatus( magnetAdaptor.booleanValue( "status" ) );
					magnet.setRollAngle( magnetAdaptor.doubleValue( "rollAngle" ) );
				}
			}
		}
    }
    
    
    /** Instructs the receiver to write its data to the adaptor for external storage. */
    public void write( final DataAdaptor adaptor ) {
        adaptor.setValue( "version", "1.0.0" );
        adaptor.setValue( "date", new java.util.Date().toString() );
		
		if ( getAccelerator() != null ) {
			adaptor.setValue( "acceleratorPath", getAcceleratorFilePath() );
			
			final AcceleratorSeq sequence = getSelectedSequence();
			if ( sequence != null ) {
				adaptor.setValue( "sequence", sequence.getId() );				
				
				final List<Electromagnet> magnets = new ArrayList( sequence.getNodesOfType( Electromagnet.s_strType ) );
				for ( final Electromagnet magnet : magnets ) {
					final DataAdaptor magnetAdaptor = adaptor.createChild( "Magnet" );
					magnetAdaptor.setValue( "id", magnet.getId() );
					magnetAdaptor.setValue( "status", magnet.getStatus() );
					magnetAdaptor.setValue( "rollAngle", magnet.getRollAngle() );
				}
			}
		}		
    }
}
